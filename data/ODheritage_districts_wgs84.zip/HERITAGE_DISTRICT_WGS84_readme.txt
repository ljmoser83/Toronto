HERITAGE_DISTRICT_WGS84_readme
 

Column name  (Description)
======================================
HRD_NAME = DISTRICT_NAME  (Name of the Heritage District)
HRD_TYPE = DESIGNATION_TYPE  (Type of Designation)
HRD_DESAT = DESIGNATION_DATE  (Designated Date)
HRD_FORNUM = FORMER_MUNICIPALITY  (Former Municipality)
HRD_BYLAWN = DESIGNATION_BY_LAW  (Designated ByLaw Number)
HRD_WARDNU = WARD_NUMBER  (Ward Number)
SHAPE_LNG = SHAPE_LENGTH
SHAPE_AREA = SHAPE_AREA
X = X  (Easting in MTM NAD27 3 degree Projection)
Y = Y  (Northing in MTM NAD27 3 degree Projection)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System)
FID = OBJECTID  (Unique system identifier)
