EDC_PUBLIC_ART_MONUMNET_WGS84_readme
 

Column name  (Description)
======================================
X_COORDI2 = X_COORDINATE  (SOURCE X COORDINATE)
Y_COORDI3 = Y_COORDINATE  (SOURCE Y COORDINATE)
PARK_NAME = PARK_NAME  (Official name of City owned parks)
RIVA_ID = RIVA_ID  (Asset code for parks as assigned by Parks Forest and Recreation)
NEAR_ST = NEAR_STREET  (The closest street to an artwork/monument)
NEAR_CST = NEAR_CROSS_STREET  (The closest nearby cross street to an artwork/monument)
ARTWORKNAM = ARTWORK_NAME  (The title of the artwork as given by the artist(s) or companies who created it)
ARTIST = ARTIST  (The name of the artist(s) or companies who created the work)
MEDIA = MEDIA  (The material used for the major components of the artwork/monument)
CREATEYEAR = CREATION_YEAR  (The date the work was completed and installed on site)
ARTWORKLOC = ARTWORK_LOCATION  (Indicates whether the artwork/ monument is located indoors or outdoors)
LONGITUDE = LONGITUDE  (Easting of address point, GCS Projection)
LATITUDE = LATITUDE  (Northing of address point, GCS Projection)
OBJECTID = OBJECTID  (Unique identifier)
ADD_FULL = ADDRESS_FULL  (The closest physical address to an artwork/ monument. )
POSTAL_CD = POSTAL_CODE  (Postal code of the closest physical address to a sculpture/ monument. )
WARD_NUM = WARD  (Ward Number)
WARD_NAME = WARD_NAME  (Ward Name)
