CULTURAL_HOTSPOT_WGS84_readme
 

Column name  (Description)
======================================
PNT_OF_INT = MOUSEOVER_INFO  (Points of interest comprise public art, murals, buildings of historical or architectural significance, cultural spaces and parks.)
DESCRPTION = INFO_1  (This field provides a brief description of the point of interest.)
SOCIAL_MED = INFO_2  (This field provideds a social media link.)
WEBSITE = INFO_3  (This field provides a website for the point of interest.)
CATEGORY = INFO_8  (Points of interest are divided into categories: business, community, creative, hertiage, library, public art, etc.)
LOCATION = LOCATION_INFO  (User defined Location Info)
X = X  (X Co-ordinate in MTM Projection)
Y = Y  (Y Co-ordinate in MTM Projection)
LONGITUDE = LONGITUDE  (Logitude, in WGS84 Coordinate System)
LATITUDE = LATITUDE  (Y Co-ordinate in WGS84 Projection)
OBJECTID = OBJECTID  (Unique Objectid for SDE)
